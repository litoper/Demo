package com.example.kadh.utils.RxJava.RxApi;

/**
 * @author: kadh
 * @email : 36870855@qq.com
 * @date : 2018/5/28
 * @blog : http://www.nicaicaicai.com
 * @desc :
 */

public interface RxApiUrl {
    class Url {

        /**
         * 版本号
         */
//        static String Ver = "Android(Build" + SPUtils.getVersionCode(DjorApp.mContext) + ")";
        public static String Ver = "";

        /**
         * 测试服务器地址
         */

        static final String NICAICAI = "";

        static final String BASE = "http://192.168.10.175/DJOA/";

        /**
         * 登录接口
         */
        static final String LOGIN = "newlogin.do" + NICAICAI;//登录接口
        static final String GETVERCODE = "verCode_login.do" + NICAICAI;//获取登录验证码
        static final String CHECKVERSION = "checkVersionCommon.do" + NICAICAI;//校验app的版本更新


    }
}
