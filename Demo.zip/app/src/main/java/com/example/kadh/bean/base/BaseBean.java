package com.example.kadh.bean.base;

import java.io.Serializable;

/**
 * @author: kadh
 * @email : 36870855@qq.com
 * @date : 2018/6/1
 * @blog : http://www.nicaicaicai.com
 * @desc :
 */
public class BaseBean implements Serializable {
}
