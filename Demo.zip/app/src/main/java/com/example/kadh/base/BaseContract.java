package com.example.kadh.base;

/**
 * @author: kadh
 * @email : 36870855@qq.com
 * @date : 2018/5/30
 * @blog : http://www.nicaicaicai.com
 * @desc :
 */
public interface BaseContract {
    interface BasePresenter<T> {
        void atachView(T view);

        void detachView();
    }

    interface BaseView {
        void showError();

        void complete();

    }
}
