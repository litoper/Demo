package com.example.kadh.utils.RxJava.RxApi;


import com.example.kadh.bean.LoginBean;
import com.example.kadh.utils.RxJava.BaseResponse;

import java.util.List;

import io.reactivex.Observable;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

/**
 * @author: kadh
 * @email : 36870855@qq.com
 * @date : 2018/5/28
 * @blog : http://www.nicaicaicai.com
 * @desc :
 */

interface RxApiService {


    @GET(RxApiUrl.Url.CHECKVERSION)
    Observable<BaseResponse<String>> checkVersion(@Query("appVersion") String version);

    @FormUrlEncoded
    @POST(RxApiUrl.Url.LOGIN)
    Observable<BaseResponse<List<LoginBean>>> login(
            @Field("name") String username,
            @Field("password") String password,
            @Field("version") String version);

}
